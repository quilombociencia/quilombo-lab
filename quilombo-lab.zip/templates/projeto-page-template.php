<?php
/**
 * Template de página amigável para projetos do Quilombo Laboratório
 * 
 * Este template é usado para gerar páginas automaticamente quando
 * projetos são publicados no sistema.
 */

if (!defined('ABSPATH')) {
    exit;
}

/**
 * Classe para geração de templates de páginas de projetos
 */
class QL_Project_Page_Template {
    
    /**
     * Gerar conteúdo HTML completo da página do projeto
     */
    public static function generate_project_page_content($projeto) {
        // Verificar se é o projeto principal do coletivo
        $is_collective_project = self::is_collective_project($projeto);
        
        $content = '';
        
        // Banner do coletivo (se aplicável)
        if ($is_collective_project) {
            $content .= self::render_collective_banner();
        }
        
        // Cabeçalho principal do projeto
        $content .= self::render_project_header($projeto);
        
        // Seção de informações principais
        $content .= self::render_project_info($projeto);
        
        // Seção de progresso e métricas
        $content .= self::render_project_progress($projeto);
        
        // Seção do laboratório (quadro Kanban)
        $content .= self::render_project_lab($projeto);
        
        // Seção de participantes e círculos
        if ($is_collective_project) {
            $content .= self::render_collective_instances($projeto);
        } else {
            $content .= self::render_project_participants($projeto);
        }
        
        // Seção de atividades recentes
        $content .= self::render_project_activities($projeto);
        
        // Seção de gestão coletiva (se disponível)
        $content .= self::render_project_funding($projeto);
        
        // Rodapé com links de ação
        $content .= self::render_project_footer($projeto);
        
        return $content;
    }
    
    /**
     * Imprimir CSS no head da página
     */
    public static function print_project_page_styles() {
        echo '<style id="ql-projeto-styles">';
        echo self::get_project_page_styles();
        echo '</style>';
    }
    
    /**
     * CSS personalizado para páginas de projeto
     */
    private static function get_project_page_styles() {
        return '
        .ql-projeto-page {
            max-width: 1200px;
            margin: 0 auto;
            padding: 20px;
            font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif;
        }
        
        .ql-projeto-header {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
            padding: 40px;
            border-radius: 12px;
            margin-bottom: 30px;
            text-align: center;
        }
        
        .ql-projeto-title {
            font-size: 2.5em;
            margin: 0 0 15px 0;
            font-weight: 700;
        }
        
        .ql-projeto-description {
            font-size: 1.2em;
            opacity: 0.9;
            max-width: 800px;
            margin: 0 auto;
            line-height: 1.6;
        }
        
        .ql-projeto-status {
            display: inline-block;
            background: rgba(255,255,255,0.2);
            padding: 8px 16px;
            border-radius: 20px;
            font-weight: 600;
            margin-top: 20px;
        }
        
        .ql-projeto-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(300px, 1fr));
            gap: 30px;
            margin-bottom: 40px;
        }
        
        .ql-projeto-card {
            background: white;
            padding: 30px;
            border-radius: 12px;
            box-shadow: 0 4px 6px rgba(0,0,0,0.1);
            border-left: 4px solid #667eea;
        }
        
        .ql-projeto-card h3 {
            color: #333;
            margin-top: 0;
            font-size: 1.4em;
            margin-bottom: 20px;
        }
        
        .ql-progresso-bar {
            background: #f0f0f0;
            height: 8px;
            border-radius: 4px;
            overflow: hidden;
            margin: 15px 0;
        }
        
        .ql-progresso-fill {
            background: linear-gradient(90deg, #667eea, #764ba2);
            height: 100%;
            transition: width 0.3s ease;
        }
        
        .ql-button {
            display: inline-block;
            background: #667eea;
            color: white;
            padding: 12px 24px;
            text-decoration: none;
            border-radius: 6px;
            font-weight: 600;
            transition: background 0.2s;
            margin: 5px;
        }
        
        .ql-button:hover {
            background: #5a6fd8;
            color: white;
        }
        
        .ql-button-secondary {
            background: #6c757d;
        }
        
        .ql-button-secondary:hover {
            background: #545b62;
        }
        
        .ql-participants-grid {
            display: grid;
            grid-template-columns: repeat(auto-fill, minmax(200px, 1fr));
            gap: 20px;
            margin: 20px 0;
        }
        
        .ql-participant-card {
            background: #f8f9fa;
            padding: 20px;
            border-radius: 8px;
            text-align: center;
            border: 1px solid #e9ecef;
        }
        
        .ql-timeline {
            border-left: 3px solid #667eea;
            padding-left: 30px;
            margin: 20px 0;
        }
        
        .ql-timeline-item {
            margin-bottom: 20px;
            padding: 15px;
            background: white;
            border-radius: 8px;
            box-shadow: 0 2px 4px rgba(0,0,0,0.1);
        }
        
        .ql-meta {
            color: #6c757d;
            font-size: 0.9em;
            margin-bottom: 10px;
        }
        
        /* Estilos para página do coletivo */
        .ql-collective-banner {
            background: linear-gradient(135deg, #2c3e50 0%, #34495e 100%);
            color: white;
            padding: 30px;
            border-radius: 12px;
            margin-bottom: 30px;
            box-shadow: 0 6px 20px rgba(0,0,0,0.15);
        }
        
        .ql-banner-content {
            display: grid;
            grid-template-columns: auto 1fr auto;
            gap: 20px;
            align-items: center;
            max-width: 1000px;
            margin: 0 auto;
        }
        
        .ql-banner-icon {
            font-size: 3em;
        }
        
        .ql-banner-text h2 {
            margin: 0 0 10px 0;
            font-size: 1.8em;
        }
        
        .ql-banner-text p {
            margin: 0;
            opacity: 0.9;
        }
        
        .ql-button-highlight {
            background: #e74c3c !important;
            animation: pulse 2s infinite;
        }
        
        @keyframes pulse {
            0% { transform: scale(1); }
            50% { transform: scale(1.05); }
            100% { transform: scale(1); }
        }
        
        .ql-instances-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(280px, 1fr));
            gap: 20px;
            margin: 25px 0;
        }
        
        .ql-instance-card {
            background: #f8f9fa;
            padding: 25px;
            border-radius: 12px;
            border-left: 4px solid #3498db;
            transition: all 0.3s ease;
        }
        
        .ql-instance-card:hover {
            transform: translateY(-2px);
            box-shadow: 0 6px 20px rgba(0,0,0,0.1);
        }
        
        .ql-instance-active {
            border-left-color: #27ae60 !important;
            background: #e8f5e8;
        }
        
        .ql-instance-potential {
            border-left-color: #f39c12 !important;
            background: #fdf6e3;
        }
        
        .ql-instance-icon {
            font-size: 2.5em;
            margin-bottom: 15px;
        }
        
        .ql-instance-card h4 {
            margin: 0 0 10px 0;
            color: #2c3e50;
            font-size: 1.3em;
        }
        
        .ql-instance-card p {
            margin-bottom: 15px;
            line-height: 1.5;
        }
        
        .ql-instance-roles {
            display: flex;
            flex-wrap: wrap;
            gap: 8px;
        }
        
        .ql-role-badge {
            background: #3498db;
            color: white;
            padding: 4px 12px;
            border-radius: 16px;
            font-size: 0.8em;
            font-weight: 600;
        }
        
        .ql-instance-active .ql-role-badge {
            background: #27ae60;
        }
        
        .ql-instance-meta,
        .ql-instance-status {
            margin-top: 10px;
        }
        
        .ql-instance-meta small,
        .ql-instance-status small {
            color: #7f8c8d;
            font-weight: 500;
        }
        
        .ql-collective-actions {
            margin-top: 30px;
            padding-top: 25px;
            border-top: 2px solid #ecf0f1;
        }
        
        .ql-collective-actions h4 {
            margin-bottom: 20px;
            color: #2c3e50;
            font-size: 1.3em;
        }
        
        .ql-action-links {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
            gap: 15px;
            margin-bottom: 20px;
        }
        
        @media (max-width: 768px) {
            .ql-projeto-page {
                padding: 10px;
            }
            
            .ql-projeto-header {
                padding: 20px;
            }
            
            .ql-projeto-title {
                font-size: 2em;
            }
            
            .ql-projeto-grid {
                grid-template-columns: 1fr;
                gap: 20px;
            }
            
            .ql-banner-content {
                grid-template-columns: 1fr;
                text-align: center;
                gap: 15px;
            }
            
            .ql-instances-grid {
                grid-template-columns: 1fr;
            }
            
            .ql-action-links {
                grid-template-columns: 1fr;
            }
        }
        ';
    }
    
    /**
     * Cabeçalho do projeto
     */
    private static function render_project_header($projeto) {
        $status_label = self::get_status_label($projeto->status ?? 'ativo');
        
        return '
        <div class="ql-projeto-page">
            <header class="ql-projeto-header">
                <h1 class="ql-projeto-title">' . esc_html($projeto->nome) . '</h1>
                <p class="ql-projeto-description">' . esc_html($projeto->descricao ?? 'Um projeto do Quilombo Laboratório') . '</p>
                <span class="ql-projeto-status">' . esc_html($status_label) . '</span>
            </header>
        ';
    }
    
    /**
     * Informações principais do projeto
     */
    private static function render_project_info($projeto) {
        $inicio = $projeto->data_inicio ? date_i18n('d/m/Y', strtotime($projeto->data_inicio)) : 'Não definido';
        $tipo = ucfirst($projeto->tipo ?? 'projeto');
        $territorio = $projeto->territorio ?? 'Não especificado';
        
        return '
            <div class="ql-projeto-grid">
                <div class="ql-projeto-card">
                    <h3>📋 Informações do Projeto</h3>
                    <p><strong>Tipo:</strong> ' . esc_html($tipo) . '</p>
                    <p><strong>Data de Início:</strong> ' . esc_html($inicio) . '</p>
                    <p><strong>Território:</strong> ' . esc_html($territorio) . '</p>
                    <p><strong>Modalidade:</strong> ' . esc_html($projeto->modalidade ?? 'Coletiva') . '</p>
                </div>
        ';
    }
    
    /**
     * Progresso e métricas do projeto
     */
    private static function render_project_progress($projeto) {
        // Calcular progresso baseado em tarefas (simulado por enquanto)
        $progresso = self::calculate_project_progress($projeto);
        $objetivo = $projeto->objetivo_financeiro ?? 0;
        
        return '
                <div class="ql-projeto-card">
                    <h3>📊 Progresso</h3>
                    <p><strong>Completude do Projeto:</strong> ' . $progresso . '%</p>
                    <div class="ql-progresso-bar">
                        <div class="ql-progresso-fill" style="width: ' . $progresso . '%"></div>
                    </div>
                    ' . ($objetivo > 0 ? '
                    <p><strong>Objetivo Financeiro:</strong> R$ ' . number_format($objetivo, 2, ',', '.') . '</p>
                    ' : '') . '
                    <p><strong>Status:</strong> ' . esc_html($projeto->status ?? 'Ativo') . '</p>
                </div>
            </div>
        ';
    }
    
    /**
     * Seção do laboratório (Quadro Kanban)
     */
    private static function render_project_lab($projeto) {
        return '
            <div class="ql-projeto-card" style="grid-column: 1 / -1;">
                <h3>🔬 Laboratório de Projetos</h3>
                <p>Quadro Kanban colaborativo para gestão de tarefas e atividades.</p>
                <div id="ql-kanban-board">
                    <div class="ql-kanban-placeholder">
                        <p><strong>Quadro de Tarefas:</strong> ' . esc_html($projeto->nome) . '</p>
                        <p>Interface de gerenciamento de tarefas estará disponível aqui.</p>
                    </div>
                </div>
                <p style="margin-top: 20px;">
                    <a href="' . admin_url('admin.php?page=quilombo-lab-projetos') . '" class="ql-button">🎯 Ver Quadro Completo</a>
                    <a href="' . admin_url('admin.php?page=quilombo-lab-projetos') . '" class="ql-button ql-button-secondary">➕ Nova Tarefa</a>
                </p>
            </div>
        ';
    }
    
    /**
     * Participantes e círculos
     */
    private static function render_project_participants($projeto) {
        return '
            <div class="ql-projeto-card" style="grid-column: 1 / -1;">
                <h3>👥 Participantes e Círculos</h3>
                <p>Pessoas envolvidas no projeto organizadas em círculos colaborativos.</p>
                
                <h4>Círculo Principal</h4>
                <div class="ql-participants-grid">
                    <div class="ql-participant-card">
                        <strong>Guia</strong>
                        <p>Responsável pela condução</p>
                    </div>
                    <div class="ql-participant-card">
                        <strong>Orientação</strong>
                        <p>Supervisão técnica</p>
                    </div>
                    <div class="ql-participant-card">
                        <strong>Operação</strong>
                        <p>Execução prática</p>
                    </div>
                    <div class="ql-participant-card">
                        <strong>Comunicação</strong>
                        <p>Divulgação e registro</p>
                    </div>
                </div>
                
                <p style="margin-top: 20px;">
                    <a href="#" class="ql-button">👋 Participar do Projeto</a>
                    <a href="#" class="ql-button ql-button-secondary">👁️ Ver Todos os Participantes</a>
                </p>
            </div>
        ';
    }
    
    /**
     * Atividades recentes
     */
    private static function render_project_activities($projeto) {
        return '
            <div class="ql-projeto-card" style="grid-column: 1 / -1;">
                <h3>📈 Atividades Recentes</h3>
                <div class="ql-timeline">
                    <div class="ql-timeline-item">
                        <div class="ql-meta">Hoje, 14:30</div>
                        <strong>Nova tarefa criada:</strong> Implementar funcionalidade X
                    </div>
                    <div class="ql-timeline-item">
                        <div class="ql-meta">Ontem, 16:45</div>
                        <strong>Tarefa concluída:</strong> Pesquisa de requisitos
                    </div>
                    <div class="ql-timeline-item">
                        <div class="ql-meta">2 dias atrás, 09:15</div>
                        <strong>Novo participante:</strong> João se juntou ao círculo
                    </div>
                </div>
                
                <p style="margin-top: 20px;">
                    <a href="#" class="ql-button ql-button-secondary">📋 Ver Histórico Completo</a>
                </p>
            </div>
        ';
    }
    
    /**
     * Gestão coletiva e recursos
     */
    private static function render_project_funding($projeto) {
        $tem_gc = class_exists('GC_Admin'); // Verificar se Gestão Coletiva está ativa
        
        if (!$tem_gc) {
            return '';
        }
        
        return '
            <div class="ql-projeto-card" style="grid-column: 1 / -1;">
                <h3>💰 Gestão Coletiva de Recursos</h3>
                <p>Administração transparente e colaborativa dos recursos do projeto.</p>
                
                <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(200px, 1fr)); gap: 20px; margin: 20px 0;">
                    <div>
                        <strong>Arrecadado:</strong><br>
                        <span style="font-size: 1.5em; color: #28a745;">R$ 0,00</span>
                    </div>
                    <div>
                        <strong>Despesas:</strong><br>
                        <span style="font-size: 1.5em; color: #dc3545;">R$ 0,00</span>
                    </div>
                    <div>
                        <strong>Saldo:</strong><br>
                        <span style="font-size: 1.5em; color: #667eea;">R$ 0,00</span>
                    </div>
                </div>
                
                <p style="margin-top: 20px;">
                    <a href="#" class="ql-button">🎁 Fazer Doação</a>
                    <a href="#" class="ql-button ql-button-secondary">📊 Ver Relatório Financeiro</a>
                </p>
            </div>
        ';
    }
    
    /**
     * Rodapé com ações
     */
    private static function render_project_footer($projeto) {
        return '
            <footer style="margin-top: 40px; padding: 30px; background: #f8f9fa; border-radius: 12px; text-align: center;">
                <h3>🚀 Participe do Projeto</h3>
                <p>Interessado em contribuir? Entre em contato ou participe das atividades.</p>
                
                <p style="margin-top: 20px;">
                    <a href="mailto:contato@quilombociencia.org" class="ql-button">✉️ Entrar em Contato</a>
                    <a href="#" class="ql-button ql-button-secondary">📱 Grupo do WhatsApp</a>
                    <a href="' . admin_url('admin.php?page=quilombo-lab-projetos') . '" class="ql-button ql-button-secondary">⚙️ Painel Admin</a>
                </p>
            </footer>
        </div>
        ';
    }
    
    /**
     * Calcular progresso do projeto baseado em tarefas
     */
    private static function calculate_project_progress($projeto) {
        // Por enquanto, retornar um valor simulado
        // TODO: Implementar cálculo real baseado em tarefas concluídas
        return rand(20, 85);
    }
    
    /**
     * Obter label do status em português
     */
    private static function get_status_label($status) {
        $labels = [
            'ativo' => 'Projeto Ativo',
            'pausado' => 'Pausado',
            'concluido' => 'Concluído',
            'arquivado' => 'Arquivado'
        ];
        
        return $labels[$status] ?? 'Status Desconhecido';
    }
    
    /**
     * Verificar se é o projeto principal do coletivo
     */
    private static function is_collective_project($projeto) {
        // Critérios para identificar projeto do coletivo:
        // 1. Nome contém "Quilombo Ciência" e não é um fundo
        // 2. Ou slug específico
        $nome_lower = strtolower($projeto->nome);
        
        if (strpos($nome_lower, 'quilombo ciência') !== false && 
            strpos($nome_lower, 'fundo') === false) {
            return true;
        }
        
        // Verificar por slug específico
        if ($projeto->slug === 'quilombo-ciencia' || $projeto->slug === 'projeto-coletivo') {
            return true;
        }
        
        return false;
    }
    
    /**
     * Renderizar banner do coletivo
     */
    private static function render_collective_banner() {
        return '
            <div class="ql-collective-banner">
                <div class="ql-banner-content">
                    <div class="ql-banner-icon">🏛️</div>
                    <div class="ql-banner-text">
                        <h2>Projeto Principal do Coletivo</h2>
                        <p>Esta é a página do projeto responsável pela organização do coletivo Quilombo Ciência</p>
                    </div>
                    <div class="ql-banner-action">
                        <a href="https://quilombociencia.org" class="ql-button ql-button-highlight" target="_blank">
                            🌐 Visitar Site do Coletivo
                        </a>
                    </div>
                </div>
            </div>
        ';
    }
    
    /**
     * Renderizar instâncias do coletivo
     */
    private static function render_collective_instances($projeto) {
        return '
            <div class="ql-projeto-card" style="grid-column: 1 / -1;">
                <h3>🏛️ Instâncias do Coletivo</h3>
                <p>Organização e estrutura do coletivo Quilombo Ciência conforme modelo organizativo.</p>
                
                <div class="ql-instances-grid">
                    <div class="ql-instance-card ql-instance-active">
                        <div class="ql-instance-icon">⚪</div>
                        <h4>Círculo Principal</h4>
                        <p>Núcleo inicial do coletivo responsável pela coordenação geral</p>
                        <div class="ql-instance-roles">
                            <span class="ql-role-badge">Guia</span>
                            <span class="ql-role-badge">Orientação</span>
                            <span class="ql-role-badge">Gestão</span>
                        </div>
                    </div>
                    
                    <div class="ql-instance-card">
                        <div class="ql-instance-icon">🌐</div>
                        <h4>Núcleo Virtual</h4>
                        <p>Espaço digital de articulação e coordenação</p>
                        <div class="ql-instance-meta">
                            <small>Página: quilombociencia.org</small>
                        </div>
                    </div>
                    
                    <div class="ql-instance-card ql-instance-potential">
                        <div class="ql-instance-icon">📍</div>
                        <h4>Núcleos Territoriais</h4>
                        <p>Espaços físicos de articulação em territórios específicos</p>
                        <div class="ql-instance-status">
                            <small>Em formação</small>
                        </div>
                    </div>
                    
                    <div class="ql-instance-card ql-instance-potential">
                        <div class="ql-instance-icon">🎯</div>
                        <h4>Eventos e Assembleias</h4>
                        <p>Instâncias temporárias para decisões coletivas</p>
                        <div class="ql-instance-status">
                            <small>Conforme demanda</small>
                        </div>
                    </div>
                </div>
                
                <div class="ql-collective-actions">
                    <h4>Ações do Coletivo</h4>
                    <div class="ql-action-links">
                        <a href="https://quilombociencia.org/blog" class="ql-button ql-button-secondary">📝 Pilão de Ideias</a>
                        <a href="https://quilombociencia.org/escola" class="ql-button ql-button-secondary">🎓 Escola de Projetos</a>
                        <a href="' . admin_url('admin.php?page=quilombo-lab-projetos') . '" class="ql-button ql-button-secondary">🔬 Laboratório</a>
                        <a href="#" class="ql-button ql-button-secondary">💰 Gestão Coletiva</a>
                    </div>
                </div>
                
                <p style="margin-top: 20px;">
                    <a href="#" class="ql-button">👋 Participar do Coletivo</a>
                    <a href="#" class="ql-button ql-button-secondary">📋 Ver Jornadas Disponíveis</a>
                </p>
            </div>
        ';
    }
}