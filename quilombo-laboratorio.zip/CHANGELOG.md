# Changelog - Quilombo Laboratório de Projetos

Todas as mudanças notáveis neste projeto serão documentadas neste arquivo.

O formato é baseado em [Keep a Changelog](https://keepachangelog.com/pt-BR/1.0.0/),
e este projeto adere ao [Semantic Versioning](https://semver.org/lang/pt-BR/spec/v2.0.0.html).

## [1.0.3-production] - 2025-01-23

### ✨ Adicionado
- Sistema de auto-correção de problemas conhecidos
- Limpeza automática de cache problemático na inicialização
- Verificação contínua de capabilities para administradores
- CSS separado para cards de projetos (`assets/css/project-cards.css`)
- Logs detalhados para monitoramento de operações

### 🎨 Melhorado
- **Interface dos Cards de Projetos:**
  - Altura padronizada de 350px para todos os cards
  - Remoção automática de HTML das descrições usando `wp_strip_all_tags()`
  - Truncamento inteligente de texto longo (120 caracteres) com "..."
  - Layout flexbox com distribuição consistente de conteúdo
  - Hover effects sutis com sombra
  - Design responsivo melhorado para mobile

- **Sistema de Permissões:**
  - Configuração automática completa de capabilities na ativação
  - Lista expandida de permissões necessárias
  - Verificação e correção automática de capabilities ausentes
  - Suporte aprimorado para diferentes níveis de usuário

### 🔧 Corrigido
- **Problemas de Exibição:**
  - Projetos não aparecendo por falta de capability `view_all_projects`
  - Status de projetos NULL/vazio sendo corrigido automaticamente para 'active'
  - HTML renderizado incorretamente nos resumos dos cards
  - Tamanhos inconsistentes de cards dependendo do conteúdo

- **Performance:**
  - Cache desatualizado interferindo na listagem de projetos
  - Transients problemáticos sendo removidos automaticamente
  - Object cache sendo limpo quando necessário

### 🧹 Removido
- Scripts de correção desnecessários que não são mais necessários:
  - `correcao-permissoes-usuario.php`
  - `correcao-pagina-projetos.php` 
  - `correcao-cards-projetos.php`
  - `diagnostico-sistema-completo.php`
  - `diagnostico-projetos-especifico.php`
  - `debug-interface-projetos.php`

### 📚 Documentação
- README.md completamente reescrito e atualizado
- Seção "Solução de Problemas" com problemas resolvidos automaticamente
- Documentação de logs e monitoramento
- Changelog criado para versionamento adequado

### 🔒 Segurança
- Sanitização rigorosa de dados de entrada
- Verificações de permissão aprimoradas
- Validação de integridade de banco contínua

## [1.0.2-production] - 2025-01-22

### 🔧 Corrigido
- Integração estabilizada com Plugin Gestão Coletiva
- Sistema de sincronização melhorado
- Correções de bugs menores na interface

### ⚡ Melhorado
- Performance geral do plugin
- Compatibilidade com versões mais recentes do WordPress

## [1.0.0-beta] - 2025-01-15

### ✨ Inicial
- Lançamento inicial do plugin
- Funcionalidades básicas de gestão de projetos
- Integração com Plugin Gestão Coletiva
- Sistema básico de quadros Kanban
- Interface administrativa fundamental

### 📋 Funcionalidades
- Criação e gestão de projetos
- Sistema básico de permissões
- Integração com Moodle através do GC
- Dashboard administrativo simples

---

## Legenda dos Tipos de Mudança

- ✨ **Adicionado** - Para novas funcionalidades
- 🎨 **Melhorado** - Para mudanças em funcionalidades existentes  
- 🔧 **Corrigido** - Para correções de bugs
- 🧹 **Removido** - Para funcionalidades removidas
- 📚 **Documentação** - Para mudanças na documentação
- 🔒 **Segurança** - Para correções de vulnerabilidades
- ⚡ **Performance** - Para melhorias de performance
- 🔄 **Alterado** - Para mudanças em funcionalidades existentes

---

**Padrão de Versionamento:**
- **MAJOR.MINOR.PATCH-STAGE**
- **MAJOR**: Mudanças incompatíveis na API
- **MINOR**: Funcionalidades adicionadas de forma compatível
- **PATCH**: Correções de bugs compatíveis
- **STAGE**: beta, rc, production